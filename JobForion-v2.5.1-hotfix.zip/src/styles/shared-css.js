// Shared design tokens and site-wide UI primitives.
// The visual language follows the supplied JobForion UI reference while
// keeping the existing server-rendered class contract intact.

export const SHARED_CSS = `
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#ffffff;--bg2:#faf9ff;--surface:#ffffff;--surface2:#f8f7fc;
  --border:#eceaf2;--border2:#ddd9e9;
  --ink:#181632;--ink2:#45415e;--ink3:#7d798f;
  --brand:#6339e6;--brand2:#4f2bd0;--brand-soft:#f1edff;
  --navy:#191735;--navy2:#26224d;--navy-border:#39345d;--navy-ink2:#b8b4d2;
  --green:#2dad69;--amber:#d99a22;--coral:#ff6f8a;--cyan:#54c4d2;--pink:#df64a6;
  --pastel-blue:#f0ecff;--pastel-yellow:#fff8e4;--pastel-pink:#fff0f7;--pastel-green:#eafaf1;
  --salary:#2a9a66;--font-mono:'JetBrains Mono',ui-monospace,'SF Mono',Menlo,monospace;
  --r:12px;--shadow:0 2px 10px rgba(37,24,92,.05);--shadow-lg:0 16px 40px rgba(39,24,105,.12);
  --shadow-card:0 1px 2px rgba(37,24,92,.04),0 8px 24px -4px rgba(37,24,92,.08);
  --shadow-card-hover:0 4px 12px rgba(37,24,92,.06),0 20px 40px -8px rgba(99,57,230,.16);
}
html{scroll-behavior:auto;-webkit-text-size-adjust:100%;text-size-adjust:100%}
body{font-family:var(--font-body,'Inter','Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif);background:var(--bg);color:var(--ink);min-height:100vh;line-height:1.6;-webkit-font-smoothing:antialiased}
h1,h2,h3,.font-display{font-family:var(--font-heading,'Plus Jakarta Sans','Inter',sans-serif);font-weight:700}
::-webkit-scrollbar{width:7px}::-webkit-scrollbar-track{background:var(--bg2)}::-webkit-scrollbar-thumb{background:#d8d2eb;border-radius:4px}
a{color:inherit;text-decoration:none}button{font-family:inherit}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid rgba(99,57,230,.22);outline-offset:2px}
@keyframes pulse-dot{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(1.55)}}
@keyframes fadeInUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes skeleton{0%{background-position:200% 0}100%{background-position:-200% 0}}
@keyframes toast-bar{from{width:100%}to{width:0}}
@keyframes slideDown{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}

/* Header: white, light, and closer to the supplied reference. */
.nav{height:var(--nav-header-height,var(--layout-header-height,72px));padding:0 28px;display:flex;align-items:center;justify-content:space-between;gap:var(--nav-gap,28px);background:rgba(255,255,255,.94);border-bottom:1px solid #efedf5;position:sticky;top:0;z-index:200;backdrop-filter:blur(16px)}
.nav-logo{font-family:var(--font-heading,sans-serif);font-size:21px;font-weight:700;letter-spacing:-.8px;color:var(--ink);display:flex;align-items:center;gap:8px;white-space:nowrap}
.nav-logo img{width:var(--nav-logo-size,31px);height:var(--nav-logo-size,31px);border-radius:var(--radius-md,9px);object-fit:contain}.nav-logo .dot{width:5px;height:5px;border-radius:50%;background:var(--brand);margin-left:-4px;margin-top:17px}
.nav-links{display:flex;align-items:center;gap:calc(var(--nav-gap,28px) * .18);margin-left:auto}.nav-link{padding:10px 12px;border-radius:8px;font-size:12.5px;font-weight:800;color:#5d596f;transition:all var(--transition-fast,.18s);border:none;background:none;cursor:pointer;font-family:inherit;white-space:nowrap}.nav-link:hover{color:var(--brand);background:var(--brand-soft)}.nav-account{position:relative;display:flex;align-items:center}.nav-account-trigger{display:flex;align-items:center;gap:7px;padding:6px 8px;border-radius:9px;color:var(--ink2);font-size:12.5px;font-weight:800;text-decoration:none}.nav-account-trigger:hover{background:var(--brand-soft);color:var(--brand)}.nav-user-avatar{display:inline-flex;align-items:center;justify-content:center;width:25px;height:25px;border-radius:50%;background:var(--brand-soft);color:var(--brand);font:800 12px var(--font-heading,sans-serif)}.nav-account-menu{position:absolute;right:0;top:calc(100% + 8px);display:none;width:178px;padding:7px;border:1px solid var(--border);border-radius:11px;background:var(--surface);box-shadow:var(--shadow-lg);z-index:400}.nav-account:hover .nav-account-menu,.nav-account:focus-within .nav-account-menu{display:grid}.nav-account-menu a,.nav-account-menu button{display:flex;align-items:center;gap:8px;width:100%;padding:9px;border:0;border-radius:7px;background:transparent;color:var(--ink2);font:800 12.5px var(--font-body,sans-serif);text-decoration:none;text-align:left;cursor:pointer}.nav-account-menu a:hover,.nav-account-menu button:hover{background:var(--brand-soft);color:var(--brand)}.nav-account-menu form{margin:0;border-top:1px solid var(--border);margin-top:4px;padding-top:4px}
.nav-cta{background:linear-gradient(110deg,var(--brand),var(--brand2));color:#fff;border:none;border-radius:8px;padding:11px 17px;font-size:12.5px;font-weight:800;transition:all var(--transition-fast,.18s);cursor:pointer;margin-left:8px;box-shadow:0 7px 16px rgba(99,57,230,.2);white-space:nowrap}.nav-cta:hover{transform:translateY(-1px);box-shadow:0 10px 22px rgba(99,57,230,.28)}
@media(max-width:960px){.nav{padding:0 18px;gap:12px}.nav-links{gap:0}.nav-links .nav-link{padding-left:8px;padding-right:8px;font-size:12px}}
@media(max-width:760px){.nav{display:none!important}}

/* Mobile header and menu. */
.mob-hdr{display:none;padding:0 16px;height:64px;background:rgba(255,255,255,.96);border-bottom:1px solid var(--border);align-items:center;justify-content:space-between;position:sticky;top:0;z-index:200;gap:10px;backdrop-filter:blur(16px)}
.mob-logo{font-family:var(--font-heading,sans-serif);font-size:19px;font-weight:700;color:var(--ink);display:flex;align-items:center;gap:7px}.mob-logo img{width:29px;height:29px;border-radius:8px;object-fit:contain}.mob-account-indicator{display:flex;align-items:center;justify-content:center;position:absolute;right:14px;width:31px;height:31px;border:2px solid var(--ink);border-radius:50%;text-decoration:none}.mob-account-indicator span{width:8px;height:8px;border-radius:50%;background:var(--brand);position:absolute;top:-4px;right:0;border:1.5px solid #fff}.mob-account-indicator span:not(:empty){position:static;width:100%;height:100%;display:flex;align-items:center;justify-content:center;border:0;background:var(--brand-soft);color:var(--brand);font:800 12.5px var(--font-heading,sans-serif)}.mob-account-indicator span:empty{width:8px;height:8px;background:var(--brand);position:absolute;top:-4px;right:0;border:1.5px solid #fff}.mob-burger{width:38px;height:38px;border-radius:9px;border:1px solid var(--border2);background:var(--surface);color:var(--ink);display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:16px;transition:all var(--transition-fast,.18s);flex-shrink:0}.mob-burger:active,.mob-burger.is-open{background:var(--brand-soft);border-color:#c6baf5;color:var(--brand);transform:scale(.96)}
.mob-menu{display:none;position:fixed;left:0;right:0;top:64px;bottom:68px;z-index:330;background:rgba(255,255,255,.99);border-bottom:1px solid var(--border);box-shadow:var(--shadow-lg);padding:28px 20px 18px;animation:slideDown .2s ease;overflow-y:auto}.mob-menu.open{display:block}.mob-menu a,.mob-menu button{display:flex;align-items:center;gap:14px;width:100%;text-align:left;padding:14px 12px;border-radius:10px;color:var(--ink);font-size:14px;font-weight:800;border:none;background:none;cursor:pointer;font-family:inherit}.mob-menu a:active,.mob-menu button:active{background:var(--brand-soft)}.mob-menu .mob-menu-post-btn{margin-top:10px;justify-content:center;background:var(--brand);color:#fff;border-radius:10px;font-size:15px;padding:15px 14px;box-shadow:0 8px 18px rgba(99,57,230,.24)}
@media(max-width:760px){.mob-hdr{display:flex;justify-content:center;position:sticky}.mob-logo{font-size:17px}.mob-burger{position:absolute;left:14px}.mob-hdr::after,.mob-hdr::before{display:none}}

/* Footer: richer columns and the same deep ink tone as the reference. */
.mobile-bottom-nav{display:none}@media(max-width:760px){body{padding-bottom:68px}.mobile-bottom-nav{position:fixed;display:grid;grid-template-columns:repeat(5,1fr);left:0;right:0;bottom:0;height:68px;background:rgba(255,255,255,.97);border-top:1px solid #eceaf2;box-shadow:0 -8px 24px rgba(33,25,73,.08);z-index:350;padding:7px 6px max(7px,env(safe-area-inset-bottom));backdrop-filter:blur(16px)}.mobile-bottom-item{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;color:#858094;font-size:11.5px;font-weight:800;line-height:1;text-decoration:none;border-radius:9px;transition:color .18s,background .18s}.mobile-bottom-item svg{width:18px;height:18px}.mobile-bottom-item.active{color:var(--brand);background:#f7f4ff}.mobile-bottom-item:active{transform:scale(.96)}}
.site-footer{background:var(--navy);color:var(--navy-ink2);padding:48px 24px 24px;margin-top:46px}.sf-inner{max-width:var(--container-width,1150px);margin:0 auto}.sf-top{display:grid;grid-template-columns:1.45fr repeat(4,1fr);gap:var(--card-gap,30px);padding-bottom:34px;border-bottom:1px solid var(--navy-border)}.sf-brand{display:flex;align-items:center;gap:8px;font-family:var(--font-heading,sans-serif);font-size:20px;font-weight:700;color:#fff;margin-bottom:12px}.sf-brand img{width:30px;height:30px;border-radius:8px;object-fit:contain}.sf-desc{font-size:12.5px;line-height:1.8;max-width:260px;margin-bottom:16px}.sf-social{display:flex;gap:8px}.sf-social a,.sf-social button{width:31px;height:31px;border-radius:8px;background:rgba(255,255,255,.06);border:1px solid var(--navy-border);display:flex;align-items:center;justify-content:center;transition:all var(--transition-fast,.18s);padding:0;font:inherit;color:inherit}.sf-social a{cursor:pointer}.sf-social button{cursor:default}.sf-social a:hover,.sf-social button:not(:disabled):hover{background:var(--brand);border-color:var(--brand)}.sf-social button:disabled{opacity:.78}.sf-social svg{width:14px;height:14px;fill:#fff}.sf-col-title{font-size:12px;font-weight:800;letter-spacing:.9px;text-transform:uppercase;color:#fff;margin-bottom:14px}.sf-col a{display:block;font-size:12.5px;color:var(--navy-ink2);margin-bottom:10px;transition:color .18s}.sf-col a:hover{color:#fff}.sf-col .footer-action{display:block;padding:0;margin:0 0 10px;border:0;background:none;color:var(--navy-ink2);font:12.5px var(--font-body,sans-serif);cursor:pointer;text-align:left;transition:color .18s}.sf-col .footer-action:hover{color:#fff}.sf-bottom{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;padding-top:20px;font-size:12px}
@media(max-width:960px){.sf-top{grid-template-columns:1.4fr repeat(2,1fr);gap:25px}.sf-intro{grid-column:span 3}}@media(max-width:760px){.sf-top{grid-template-columns:1fr 1fr;gap:25px}.sf-intro{grid-column:span 2}.site-footer{padding-left:18px;padding-right:18px}}@media(max-width:480px){.sf-top{grid-template-columns:1fr}.sf-bottom{display:block}.sf-bottom span{display:block;margin-bottom:5px}}

.ad-slot{border:1.5px dashed var(--border2);border-radius:var(--radius-md,12px);padding:14px;text-align:center;margin:16px 0;background:var(--surface2)}.ad-slot-label{font-size:11.5px;font-weight:800;letter-spacing:1.4px;text-transform:uppercase;color:var(--ink3);margin-bottom:4px}.ad-slot-hint{font-size:12px;color:var(--ink3)}.ad-slot-live{border:none;padding:0;background:transparent;display:flex;justify-content:center;overflow:hidden}
.tag-pinned{background:var(--brand-soft);color:var(--brand);border:none;font-size:12px;padding:3px 9px;font-weight:800;letter-spacing:.3px;border-radius:20px}.jt-badge{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:800;padding:3px 9px;border-radius:20px;letter-spacing:.2px;white-space:nowrap}.jt-card-featured{transform:scale(1.008)}.jt-card-featured:hover{box-shadow:0 10px 26px rgba(99,57,230,.2);transform:scale(1.015) translateY(-2px)}.jt-card-premium,.jt-card-sponsored{position:relative}.jt-card-premium:hover,.jt-card-sponsored:hover{box-shadow:0 14px 34px rgba(99,57,230,.18);transform:translateY(-3px)}.jt-card-premium .job-title-card,.jt-card-sponsored .job-title-card{font-weight:800}.jt-note{font-size:12.5px;color:var(--ink3);margin-top:6px;font-style:italic;line-height:1.4}.related-jt-tier{font-size:13px}.related-card.jt-card-featured,.related-card.jt-card-premium,.related-card.jt-card-sponsored{padding:14px 16px}.salary-tier-badge{display:inline-flex;align-items:center;max-width:100%;font-size:11.5px;line-height:1.2;padding:3px 8px;border:1px solid;border-radius:20px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.salary-tier-high{background:var(--salary-high-bg,#eafaf1);color:var(--salary-high-text,#18794e);border-color:var(--salary-high-border,#b9e7ce)}.salary-tier-good{background:var(--salary-good-bg,#f0ecff);color:var(--salary-good-text,#5732c4);border-color:var(--salary-good-border,#cfc3fa)}.salary-tier-standard{background:var(--salary-standard-bg,#f5f5f7);color:var(--salary-standard-text,#5f5b6d);border-color:var(--salary-standard-border,#dfdce7)}

/* Post-a-job modal. */
.pj-overlay{display:none;position:fixed;inset:0;background:rgba(22,18,52,.55);backdrop-filter:blur(4px);z-index:500;align-items:flex-start;justify-content:center;padding:32px 16px;overflow-y:auto}.pj-overlay.open{display:flex;animation:fadeIn .2s ease}.pj-modal{background:var(--surface);border-radius:16px;max-width:560px;width:100%;padding:28px 26px 26px;box-shadow:var(--shadow-lg);position:relative;margin:auto}.pj-close{position:absolute;top:16px;right:16px;width:32px;height:32px;border-radius:9px;border:1px solid var(--border2);background:var(--surface2);color:var(--ink2);cursor:pointer;font-size:15px}.pj-title{font-family:var(--font-heading,sans-serif);font-size:22px;font-weight:700;color:var(--ink);margin-bottom:4px}.pj-sub{font-size:13px;color:var(--ink3);margin-bottom:20px}.pj-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.pj-group{margin-bottom:14px}.pj-label{font-size:12px;font-weight:800;color:var(--ink2);margin-bottom:6px;display:block;letter-spacing:.5px;text-transform:uppercase}.pj-input,.pj-select,.pj-textarea{width:100%;background:var(--surface2);border:1.5px solid var(--border2);border-radius:9px;padding:11px 13px;color:var(--ink);font-size:13.5px;font-family:inherit;outline:none;transition:all var(--transition-fast,.18s)}.pj-input:focus,.pj-select:focus,.pj-textarea:focus{border-color:var(--brand);box-shadow:0 0 0 3px var(--brand-soft)}.pj-textarea{resize:vertical;min-height:80px}.pj-submit{width:100%;background:var(--brand);color:#fff;padding:13px;border-radius:9px;font-size:14px;font-weight:800;border:none;cursor:pointer;margin-top:6px;transition:all var(--transition-fast,.18s)}.pj-submit:hover{background:var(--brand2);box-shadow:0 8px 18px rgba(99,57,230,.2)}.pj-submit:disabled{opacity:.6;cursor:default}.pj-success{text-align:center;padding:20px 0}.pj-success .ico{font-size:44px;margin-bottom:10px}@media(max-width:480px){.pj-row{grid-template-columns:1fr}}

/* ═══ Touch, scrolling & motion layer ═══
   Goals: effortless one-thumb scrolling and tapping, and almost no motion.
   • no smooth-scroll animation, no scroll-linked effects
   • 44px minimum touch targets on phones, no 300ms tap delay, no grey tap flash
   • no backdrop-filter on phones (the single biggest cause of sticky-header scroll jank)
   • transforms never fire on hover for touch screens (stuck hover states)
   • everything animated is disabled for users who ask for reduced motion */
a,button,[role="button"],input,select,textarea,label,summary{touch-action:manipulation;-webkit-tap-highlight-color:transparent}
body{overscroll-behavior-x:none}
.filters-bar,.chip-row,.adm-mobile-nav{-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain;scrollbar-width:none}
.filters-bar::-webkit-scrollbar,.chip-row::-webkit-scrollbar{display:none}
.site-footer{content-visibility:auto;contain-intrinsic-size:auto 520px}
@media(max-width:760px){
  .nav,.mob-hdr,.mobile-bottom-nav,.pj-overlay{-webkit-backdrop-filter:none!important;backdrop-filter:none!important}
  .nav,.mob-hdr{background:var(--surface)!important}
  .mobile-bottom-nav{background:var(--surface)!important}
  .mob-menu a,.mob-menu button{min-height:48px}
  .mobile-bottom-item{min-height:48px;font-size:11.5px}
  .mob-burger{width:44px;height:44px}
  .chip,.filter-select,.text-button,.page-btn,.pj-submit,.pj-input,.pj-select{min-height:44px}
  .pj-input,.pj-select,.pj-textarea,.form-input,.sc-input,.sc-select{font-size:16px!important} /* iOS Safari zooms any input under 16px */
  .pj-overlay{padding:0;align-items:stretch}
  .pj-modal{border-radius:0;min-height:100%;max-width:none}
}
@media(hover:none){*:hover{transform:none!important}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}}
`;
